#!/usr/bin/env python

import rospy
from std_srvs.srv import SetBool

def set_vacuum_gripper_state(state):
    rospy.wait_for_service('/xarm/vacuum_gripper_set')
    try:
        vacuum_gripper_set = rospy.ServiceProxy('/xarm/vacuum_gripper_set', SetBool)
        response = vacuum_gripper_set(state)
        if response.success:
            rospy.loginfo("Vacuum gripper state set to %d", state)
        else:
            rospy.logwarn("Failed to set vacuum gripper state")
    except rospy.ServiceException as e:
        rospy.logerr("Service call failed: %s", str(e))

if __name__ == '__main__':
    rospy.init_node('vacuum_gripper_control')
    set_vacuum_gripper_state(True)  # Set the vacuum gripper state to "1" (on)
